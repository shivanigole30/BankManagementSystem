package com.BankManagementProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AdminOperation {
	static Connection con=null;
	static PreparedStatement pst=null;
	static ResultSet rst=null;
	
	static String accno;
	static Scanner sc=new Scanner(System.in);
	public static void adminDisplay() throws SQLException {
		con=DatabaseConnection.getConnection();
	
		String sel4="select * from bank_acc";
		pst=con.prepareStatement(sel4);
		
		rst=pst.executeQuery();
		System.out.println("Account No\t\tCustomer Id\t\tBalance");
		System.out.println("-----------------------------------------------------------------------------");
		while(rst.next()) {
			
			String ac=rst.getString(1);
			int cid=rst.getInt(2);
			double bal=rst.getDouble(3);
			System.out.println("-----------------------------------------------------------------------------");
			System.out.println(ac+"\t\t"+cid+"\t\t\t"+bal);
			
		}
	
	}
	public static void totalBal() throws SQLException {
		con=DatabaseConnection.getConnection();
	
		String sel4="select count(*) from bank_acc";
		pst=con.prepareStatement(sel4);
		
		rst=pst.executeQuery();
		
		System.out.println("-----------------------------------------------------------------------------");
		while(rst.next()) {
			System.out.println("Total Accounts in Bank="+rst.getInt(1)+" ");
			
		}
		String sel="select sum(balance) from bank_acc";
          pst=con.prepareStatement(sel);
		
		rst=pst.executeQuery();
		
		System.out.println("-----------------------------------------------------------------------------");
		while(rst.next()) {
			System.out.println("Total Balance in Bank="+rst.getInt(1)+" ");
			
		}
}}
