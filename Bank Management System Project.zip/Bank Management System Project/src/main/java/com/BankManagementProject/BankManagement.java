package com.BankManagementProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class BankManagement {

	static Connection con=null;
	static PreparedStatement pst=null;
	static ResultSet rst=null;
	static int cid;
	static String username;
	static String password;
	static String accno;
	static double balance;
	static String accnocheck;
	static Scanner sc=new Scanner(System.in);
	
	
	 public static void userRegister() throws SQLException {
     con = DatabaseConnection.getConnection();
     
     String sel="select * from user_acc where cid=?";
     pst=con.prepareStatement(sel);
     System.out.println("Enter user id");
     cid=sc.nextInt();
     pst.setInt(1, cid);
     rst=pst.executeQuery();
     if(!rst.next()) {
    	 System.out.println("Enter Your UserName");
    	 username=sc.next();
    	 System.out.println("Enter your password");
    	 password=sc.next();
    	 System.out.println("Enter Account No");
    	 accno=sc.next();
    while(true) {
    	String ins="insert into user_acc values(?,?,?,?)";
    	pst=con.prepareStatement(ins);
    	pst.setInt(1, cid);
    	pst.setString(2, username);
    	pst.setString(3, password);
    	pst.setString(4, accno);
    	int i=pst.executeUpdate();
    	if(i>0) {
    	String in="insert into bank_acc values(?,?,?)";
		pst=con.prepareStatement(in);
		pst.setString(1, accno);
		pst.setInt(2, cid);
		pst.setDouble(3, balance);
		int j=pst.executeUpdate();
    	if(j>0) {
    		System.out.println("Registered Successfully");
    		break;
    	}
    }
    }
     }else {
    	 System.out.println("User id is already registered");
     }
	 }
	 
 public static void loginUser() throws SQLException   {
	 con=DatabaseConnection.getConnection();
	 while(true) {
		 System.out.println("enter user name");
		 username=sc.next();
		 System.out.println("enter password");
		 password=sc.next();
		 String sel1="select * from user_acc where cname=?";
		 pst=con.prepareStatement(sel1);
		 pst.setString(1, username);
		 rst=pst.executeQuery();
		 if(rst.next()) {
			String sel2="select * from user_acc where password=?";
			pst=con.prepareStatement(sel2);
			pst.setString(1, password);
			rst=pst.executeQuery();
			if(rst.next()) {
				System.out.println("Login Successful");
				while(true) {
					System.out.println("1. Deposite Money");
					System.out.println("2. Withdraw Money");
					System.out.println("3. Display Account details");
					System.out.println("4. Exit");
					
					System.out.println("Enter Your choice");
					int ch=sc.nextInt();
					switch(ch) {
					case 1: System.out.println("Deposite Money In your Account");
					System.out.println("Enter your account no");
					accno=sc.next();
					System.out.println("Enter how much money you want to deposite ");
					balance =sc.nextDouble();
					
				    String sel="select * from bank_acc where accno=?";
				    pst=con.prepareStatement(sel);
				    pst.setString(1,accno);
				    rst=pst.executeQuery();
				    if(rst.next()) {
				    String dep="update bank_acc set balance=balance+? where accno=?";
				    pst=con.prepareStatement(dep);
				    pst.setDouble(1, balance);
				    pst.setString(2, accno);
				    int u=pst.executeUpdate();
				    if(u>0) {
				    	System.out.println("Money Deposited Successfully");
				    }
				    }
					break;
					case 2:System.out.println("Withdraw Money");
					System.out.println("Enter your account number");
					accno=sc.next();
					System.out.println("Enter how much money you want to withdraw");
					balance=sc.nextDouble();
					
					String sel3="select * from bank_acc where accno=?";
					pst=con.prepareStatement(sel3);
				    pst.setString(1,accno);
				    rst=pst.executeQuery();
				   
				    if(rst.next()) {
				    	
				    String dep1="update bank_acc set balance=balance-? where accno=?";
				    pst=con.prepareStatement(dep1);
				    pst.setDouble(1, balance);
				    pst.setString(2, accno);
				    int u=pst.executeUpdate();
				    if(u>0) {
				    	System.out.println("Money Withdraw Successfully");
				    	break;
				    }
					}
					break;
					
					case 3:System.out.println("Display Account Details");
					System.out.println("Enter your account number");
					accno=sc.next();
					String sel4="select * from bank_acc where accno=?";
					pst=con.prepareStatement(sel4);
					pst.setString(1,accno );
					rst=pst.executeQuery();
					while(rst.next()) {
						System.out.println("Account No\t\tCustomer Id\t\tBalance");
						System.out.println("-----------------------------------------------------------------------------");
						String ac=rst.getString(1);
						int cid=rst.getInt(2);
						double bal=rst.getDouble(3);
						System.out.println("-----------------------------------------------------------------------------");
						System.out.println(ac+"\t\t"+cid+"\t\t\t"+bal);
					}
					break;
					
					
					
				
					case 4://exit
					break;
			}break;
		 }
	 }
	 
		 break;
	  }else {
			 System.out.println("Invalid Username or password ");
			 break;
		 }
	
	
 }}}

