package com.BankManagementProject;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

	    static Connection con; // Global Connection Object
	    static String mysqlJDBCDriver = "com.mysql.cj.jdbc.Driver"; //jdbc driver
        static String url = "jdbc:mysql://localhost:3306/bankmanagement"; //mysql url
        static String user = "root";        //mysql username
        static String pass = "root";  //mysql passcode
	    public static Connection getConnection()
	    {
	        try {
	          
	             Class.forName(mysqlJDBCDriver);
	            con = DriverManager.getConnection(url, user, pass);
	        }
	        catch (Exception e) {
	            System.out.println("Connection Failed!");
	        }
	 
	        return con;
	    }
	}

