package com.BankManagementProject;

import java.sql.SQLException;
import java.util.Scanner;

public class MainOperations {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		Scanner  sc = new Scanner(System.in);
	        String adminname;
	        String adminpass;
	        int ch;
	        while (true) {
	            System.out.println( "----------- Welcome to Bank Management System---------- ");
	            System.out.println("1. Admin Login");
	            System.out.println("2. New User Registration");
	            System.out.println("3. User Login");
	            System.out.println("4. Exit");
	           
	                System.out.print("Enter Your Choice:"); //user input
	                ch = sc.nextInt();
	 
	                switch (ch) {
	                case 1://admin process
	                        System.out.println("Your Choose Admin Process");
	                        System.out.println("Enter Admin name");
	                        adminname=sc.next();
	                        System.out.println("Enter Admin Password");
	                        adminpass=sc.next();
	                        if(adminname.equals("admin")&& adminpass.equals("admin123")) {
	                        	
	                        	System.out.println("------------------------Admin Screen--------------------------");
	                        	System.out.println("1. User Accounts");
	                        	System.out.println("2. Total Accounts & Balance In Bank");
	                        	System.out.println("3. Exit");
	                        	System.out.println("Enter your choice");
	                        	int ch2=sc.nextInt();
	                        	switch(ch2) {
	                        	case 1:
	                        		System.out.println("------------------------User Accounts------------------------");
	                        		AdminOperation.adminDisplay();
	                        		break;
	                        	case 2: System.out.println("------------------------Total Accounts & Balance In Bank------------------------");
	                        	     AdminOperation.totalBal();   
	                        	    break;
	                        	case 3: //exit
	                        		break;
	                        	default: System.out.println("Invalid choice");
	                        	}
	                        	
	                        	break;
	                        }
	                    break;
	                        
	                //new user registration
	                case 2:System.out.println("------------------------New User Registeration------------------------");
	                BankManagement.userRegister();
	                break;
	                
	                case 3:// user login
	                	System.out.println("------------------------User Login------------------------");
	                	BankManagement.loginUser();
	                	break;
	                case 4: //exit
	                	break;
	                }
	                	
	                	System.out.println("Do you want to continue type y to continue or n to terminate");
                    	char ch1=sc.next().charAt(0);
                    	if(ch1=='n'||ch1=='N') 
                    		break;
                    	
	                               
	               
	                }
	                   System.out.println("Your program is terminated");
	        }
	       
	    }
	
	


